with open('convert.txt', 'r') as f:
    lines = f.readlines()
print(lines)
mainlst=[]
templst=[]
for i in lines:
    if i=="\n":
        continue
    else:
        lst=[]
        temp=i.split(',')
        for k in temp:
            temp2=k.split(':')
            if("\n" in temp2[-1]):
                continue
            else:
                lst.append(int(temp2[-1]))
        print(lst)
        mainlst.append(int(lst[1])+int(lst[2])+int(lst[3]))
        templst.append(lst)
print(mainlst)
ind=mainlst.index(max(mainlst))
facilities=templst[ind][1]
roadnetwork=templst[ind][2]
habitation=templst[ind][3]
print(facilities,habitation, roadnetwork)
print(mainlst.index(max(mainlst)))